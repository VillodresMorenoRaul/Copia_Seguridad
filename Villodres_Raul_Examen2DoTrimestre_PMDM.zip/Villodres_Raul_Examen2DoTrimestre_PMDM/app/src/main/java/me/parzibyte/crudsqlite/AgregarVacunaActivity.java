package me.parzibyte.crudsqlite;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import me.parzibyte.crudsqlite.controllers.VacunasController;
import me.parzibyte.crudsqlite.modelos.Vacuna;

public class AgregarVacunaActivity extends AppCompatActivity {
    private Button btnAgregarVacuna, btnCancelarNuevaVacuna;
    private EditText etNombre, etLaboratorio, etPais, etFechaAutorizacion;
    private VacunasController vacunasController;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_agregar_vacuna);

        // Instanciar vistas
        etNombre = findViewById(R.id.etAgregarNombre);
        etLaboratorio = findViewById(R.id.etAgregarLaboratorio);
        etPais = findViewById(R.id.etAgregarPais);
        etFechaAutorizacion = findViewById(R.id.etAgregarFechaAutorizacion);
        btnAgregarVacuna = findViewById(R.id.guardarNuevaVacuna);
        btnCancelarNuevaVacuna = findViewById(R.id.cancelarNuevaVacuna);

        // Crear el controlador
        vacunasController = new VacunasController(AgregarVacunaActivity.this);

        // Agregar listener del botón de guardar
        btnAgregarVacuna.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Resetear errores a ambos
                etNombre.setError(null);
                etLaboratorio.setError(null);
                etPais.setError(null);
                etFechaAutorizacion.setError(null);

                String nombre = etNombre.getText().toString();
                String laboratorio = etLaboratorio.getText().toString();
                String pais = etPais.getText().toString();
                String fechaAutorizacion = etFechaAutorizacion.getText().toString();

                if ("".equals(nombre)) {
                    etNombre.setError("Escribe el nombre de la vacuna");
                    etNombre.requestFocus();
                    return;
                }
                if ("".equals(laboratorio)) {
                    etLaboratorio.setError("Escribe el laboratorio donde se desarrolló la vacuna");
                    etLaboratorio.requestFocus();
                    return;
                }

                if ("".equals(pais)) {
                    etPais.setError("Escribe el país donde se desarrolló la vacuna");
                    etPais.requestFocus();
                    return;
                }

                if ("".equals(fechaAutorizacion)) {
                    etFechaAutorizacion.setError("Escribe la fecha de autorización de la vacuna");
                    etFechaAutorizacion.requestFocus();
                    return;
                }

                // Ya pasó la validación
                Vacuna nuevaVacuna = new Vacuna(nombre, laboratorio, pais, fechaAutorizacion);
                long id = vacunasController.nuevaVacuna(nuevaVacuna);
                if (id == -1) {
                    // De alguna manera ocurrió un error
                    Toast.makeText(AgregarVacunaActivity.this, "Error al guardar. Intenta de nuevo", Toast.LENGTH_SHORT).show();
                } else {
                    // Terminar
                    finish();
                }
            }
        });

        // El de cancelar simplemente cierra la actividad
        btnCancelarNuevaVacuna.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }
}
