package me.parzibyte.crudsqlite;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;

import java.util.ArrayList;
import java.util.List;

import me.parzibyte.crudsqlite.controllers.VacunasController;
import me.parzibyte.crudsqlite.modelos.Vacuna;

public class MainActivity extends AppCompatActivity {
    private List<Vacuna> listaDeVacunas;
    private RecyclerView recyclerView;
    private AdaptadorVacunas adaptadorVacunas;
    private VacunasController vacunasController;
    private FloatingActionButton fabAgregarVacuna;
    public static final String WEB = "https://dam.org.es/ficheros/vacunas.txt";


    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Definimos nuestro controlador
        vacunasController = new VacunasController(MainActivity.this);

        // Instanciar vistas
        recyclerView = findViewById(R.id.recyclerViewVacunas);
        fabAgregarVacuna = findViewById(R.id.fabAgregarVacuna);


        // Por defecto es una lista vacía,
        // se la ponemos al adaptador y configuramos el recyclerView
        listaDeVacunas = new ArrayList<>();
        adaptadorVacunas = new AdaptadorVacunas(listaDeVacunas);
        RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(getApplicationContext());
        recyclerView.setLayoutManager(mLayoutManager);
        recyclerView.setItemAnimator(new DefaultItemAnimator());
        recyclerView.setAdapter(adaptadorVacunas);

        startService(new Intent(MainActivity.this, DownloadService.class));

        // Una vez que ya configuramos el RecyclerView le ponemos los datos de la BD
        refrescarListaDeVacunas();

        // Listener de los clicks en la lista, o sea el RecyclerView
        recyclerView.addOnItemTouchListener(new RecyclerTouchListener(getApplicationContext(), recyclerView, new RecyclerTouchListener.ClickListener() {
            @Override // Un toque sencillo
            public void onClick(View view, int position) {
                // Pasar a la actividad EditarVacunaActivity.java
                Vacuna vacunaSeleccionada = listaDeVacunas.get(position);
                Intent intent = new Intent(MainActivity.this, EditarVacunaActivity.class);
                intent.putExtra("idVacuna", vacunaSeleccionada.getId());
                intent.putExtra("nombreVacuna", vacunaSeleccionada.getNombre());
                intent.putExtra("laboratorioVacuna", vacunaSeleccionada.getLaboratorio());
                intent.putExtra("paisVacuna", vacunaSeleccionada.getPais());
                intent.putExtra("fechaAutorizacionVacuna", vacunaSeleccionada.getFechaAutorizacion());
                startActivity(intent);
            }

            @Override // Un toque largo
            public void onLongClick(View view, int position) {
                final Vacuna vacunaParaEliminar = listaDeVacunas.get(position);
                AlertDialog dialog = new AlertDialog
                        .Builder(MainActivity.this)
                        .setPositiveButton("Sí, eliminar", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                vacunasController.eliminarVacuna(vacunaParaEliminar);
                                refrescarListaDeVacunas();
                            }
                        })
                        .setNegativeButton("Cancelar", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                dialog.dismiss();
                            }
                        })
                        .setTitle("Confirmar")
                        .setMessage("¿Eliminar la vacuna " + vacunaParaEliminar.getNombre() + "?")
                        .create();
                dialog.show();

            }
        }));

        // Listener del FAB
        fabAgregarVacuna.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Simplemente cambiamos de actividad
                Intent intent = new Intent(MainActivity.this, AgregarVacunaActivity.class);
                startActivity(intent);
            }
        });

        // Créditos
        fabAgregarVacuna.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                new AlertDialog.Builder(MainActivity.this)
                        .setTitle("Acerca de")
                        .setMessage("CRUD de Android")
                        .setNegativeButton("Cerrar", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogo, int which) {
                                dialogo.dismiss();
                            }
                        })
                        .setPositiveButton("Sitio web", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                Intent intentNavegador = new Intent(Intent.ACTION_VIEW, Uri.parse("https://parzibyte.me"));
                                startActivity(intentNavegador);
                            }
                        })
                        .create()
                        .show();
                return false;
            }
        });

    }

    @Override
    protected void onResume() {
        super.onResume();
        refrescarListaDeVacunas();
    }

    public void refrescarListaDeVacunas() {
        if (adaptadorVacunas == null) return;
        listaDeVacunas = vacunasController.obtenerVacunas();
        adaptadorVacunas.setListaDeVacunas(listaDeVacunas);
        adaptadorVacunas.notifyDataSetChanged();
    }
}
