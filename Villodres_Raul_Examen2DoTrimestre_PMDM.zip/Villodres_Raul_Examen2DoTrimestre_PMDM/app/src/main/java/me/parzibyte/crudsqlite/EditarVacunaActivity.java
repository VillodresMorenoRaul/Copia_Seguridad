package me.parzibyte.crudsqlite;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import me.parzibyte.crudsqlite.controllers.VacunasController;
import me.parzibyte.crudsqlite.modelos.Vacuna;

public class EditarVacunaActivity extends AppCompatActivity {
    private EditText etEditarNombre, etEditarLaboratorio, etEditarPais, etEditarFechaAutorizacion;
    private Button btnGuardarCambios, btnCancelarCambios;
    private Vacuna vacuna;//La vacuna que vamos a estar editando
    private VacunasController vacunasController;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_editar_vacuna);

        // Recuperar datos que enviaron
        Bundle extras = getIntent().getExtras();
        // Si no hay datos (cosa rara) salimos
        if (extras == null) {
            finish();
            return;
        }
        // Instanciar el controlador de las mascotas
        vacunasController = new VacunasController(EditarVacunaActivity.this);

        // Rearmar la vacuna
        // Nota: igualmente solamente podríamos mandar el id y recuperar la vacuna de la BD
        long idVacuna = extras.getLong("idVacuna");
        String nombreVacuna = extras.getString("nombreVacuna");
        String laboratorioVacuna = extras.getString("laboratorioVacuna");
        String paisVacuna = extras.getString("paisVacuna");
        String fechaVacuna = extras.getString("fechaVacuna");
        vacuna = new Vacuna(nombreVacuna, laboratorioVacuna, paisVacuna, fechaVacuna, idVacuna);


        // Ahora declaramos las vistas
        etEditarNombre = findViewById(R.id.etEditarNombre);
        etEditarLaboratorio = findViewById(R.id.etEditarLaboratorio);
        etEditarPais = findViewById(R.id.etEditarPais);
        etEditarFechaAutorizacion = findViewById(R.id.etEditarFechaAutorizacion);
        btnCancelarCambios = findViewById(R.id.btnCancelarCambiosVacuna);
        btnGuardarCambios = findViewById(R.id.btnGuardarCambiosVacuna);


        // Rellenar los EditText con los datos de la vacuna
        etEditarNombre.setText(vacuna.getNombre());
        etEditarLaboratorio.setText(vacuna.getLaboratorio());
        etEditarPais.setText(vacuna.getPais());
        etEditarFechaAutorizacion.setText(vacuna.getFechaAutorizacion());

        // Listener del click del botón para salir, simplemente cierra la actividad
        btnCancelarCambios.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        // Listener del click del botón que guarda cambios
        btnGuardarCambios.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Remover previos errores si existen
                etEditarNombre.setError(null);
                etEditarLaboratorio.setError(null);
                etEditarPais.setError(null);
                etEditarFechaAutorizacion.setError(null);
                // Crear la vacuna con los nuevos cambios pero ponerle
                // el id de la anterior

                String nuevoNombre = etEditarNombre.getText().toString();
                String nuevoLaboratorio = etEditarLaboratorio.getText().toString();
                String nuevoPais = etEditarPais.getText().toString();
                String nuevaFechaAutorizacion = etEditarFechaAutorizacion.getText().toString();

                if (nuevoNombre.isEmpty()) {
                    etEditarNombre.setError("Escribe el nombre");
                    etEditarNombre.requestFocus();
                    return;
                }

                if (nuevoLaboratorio.isEmpty()) {
                    etEditarLaboratorio.setError("Escribe el laboratorio");
                    etEditarLaboratorio.requestFocus();
                    return;
                }

                if (nuevoPais.isEmpty()) {
                    etEditarPais.setError("Escribe el pais");
                    etEditarPais.requestFocus();
                    return;
                }

                if (nuevaFechaAutorizacion.isEmpty()) {
                    etEditarFechaAutorizacion.setError("Escribe la fecha de autorizacion");
                    etEditarFechaAutorizacion.requestFocus();
                    return;
                }

                // Si llegamos hasta aquí es porque los datos ya están validados
                Vacuna vacunaConNuevosCambios = new Vacuna(nuevoNombre, nuevoLaboratorio, nuevoPais, nuevaFechaAutorizacion, vacuna.getId());
                int filasModificadas = vacunasController.guardarCambios(vacunaConNuevosCambios);
                if (filasModificadas != 1) {
                    // De alguna forma ocurrió un error porque se debió modificar únicamente una fila
                    Toast.makeText(EditarVacunaActivity.this, "Error guardando cambios. Intente de nuevo.", Toast.LENGTH_SHORT).show();
                } else {
                    // Si las cosas van bien, volvemos a la principal
                    // cerrando esta actividad
                    finish();
                }
            }
        });
    }
}
