package me.parzibyte.crudsqlite;

import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.List;

import me.parzibyte.crudsqlite.modelos.Vacuna;

public class AdaptadorVacunas extends RecyclerView.Adapter<AdaptadorVacunas.MyViewHolder> {

    private List<Vacuna> listaDeVacunas;

    public void setListaDeVacunas(List<Vacuna> listaDeVacunas) {
        this.listaDeVacunas = listaDeVacunas;
    }

    public AdaptadorVacunas(List<Vacuna> vacunas) {
        this.listaDeVacunas = vacunas;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View filaVacuna = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.fila_vacuna, viewGroup, false);
        return new MyViewHolder(filaVacuna);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder myViewHolder, int i) {
        // Obtener la vacuna de nuestra lista gracias al índice i
        Vacuna vacuna = listaDeVacunas.get(i);

        // Obtener los datos de la lista
        String nombreVacuna = vacuna.getNombre();
        String laboratorioVacuna = vacuna.getLaboratorio();
        String paisVacuna = vacuna.getPais();
        String fechaAutorizacionVacuna = vacuna.getFechaAutorizacion();

        // Y poner a los TextView los datos con setText
        myViewHolder.nombre.setText(nombreVacuna);
        myViewHolder.laboratorio.setText(String.valueOf(laboratorioVacuna));
        myViewHolder.pais.setText(String.valueOf(paisVacuna));
        myViewHolder.fechaAutorizacion.setText(String.valueOf(fechaAutorizacionVacuna));
    }

    @Override
    public int getItemCount() {
        return listaDeVacunas.size();
    }

    class MyViewHolder extends RecyclerView.ViewHolder {
        TextView nombre, laboratorio, pais, fechaAutorizacion;

        MyViewHolder(View itemView) {
            super(itemView);
            this.nombre = itemView.findViewById(R.id.tvNombre);
            this.laboratorio = itemView.findViewById(R.id.tvLaboratorio);
            this.pais = itemView.findViewById(R.id.tvPais);
            this.fechaAutorizacion = itemView.findViewById(R.id.tvFechaAutorizacion);
        }
    }
}
