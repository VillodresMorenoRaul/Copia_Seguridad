package me.parzibyte.crudsqlite.controllers;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;

import me.parzibyte.crudsqlite.AyudanteBaseDeDatos;
import me.parzibyte.crudsqlite.modelos.Vacuna;


public class VacunasController {
    private AyudanteBaseDeDatos ayudanteBaseDeDatos;
    private String NOMBRE_TABLA = "vacunas";

    public VacunasController(Context contexto) {
        ayudanteBaseDeDatos = new AyudanteBaseDeDatos(contexto);
    }


    public int eliminarVacuna(Vacuna vacuna) {

        SQLiteDatabase baseDeDatos = ayudanteBaseDeDatos.getWritableDatabase();
        String[] argumentos = {String.valueOf(vacuna.getId())};
        return baseDeDatos.delete(NOMBRE_TABLA, "id = ?", argumentos);
    }

    public long nuevaVacuna(Vacuna vacuna) {
        // writable porque vamos a insertar
        SQLiteDatabase baseDeDatos = ayudanteBaseDeDatos.getWritableDatabase();
        ContentValues valoresParaInsertar = new ContentValues();
        valoresParaInsertar.put("nombre", vacuna.getNombre());
        valoresParaInsertar.put("laboratorio", vacuna.getLaboratorio());
        valoresParaInsertar.put("pais", vacuna.getPais());
        valoresParaInsertar.put("fechaAutorizacion", vacuna.getFechaAutorizacion());
        return baseDeDatos.insert(NOMBRE_TABLA, null, valoresParaInsertar);
    }

    public int guardarCambios(Vacuna vacunaEditada) {
        SQLiteDatabase baseDeDatos = ayudanteBaseDeDatos.getWritableDatabase();
        ContentValues valoresParaActualizar = new ContentValues();
        valoresParaActualizar.put("nombre", vacunaEditada.getNombre());
        valoresParaActualizar.put("laboratorio", vacunaEditada.getLaboratorio());
        valoresParaActualizar.put("pais", vacunaEditada.getPais());
        valoresParaActualizar.put("fechaAutorizacion", vacunaEditada.getFechaAutorizacion());
        // where id...
        String campoParaActualizar = "id = ?";
        // ... = idVacuna
        String[] argumentosParaActualizar = {String.valueOf(vacunaEditada.getId())};
        return baseDeDatos.update(NOMBRE_TABLA, valoresParaActualizar, campoParaActualizar, argumentosParaActualizar);
    }

    public ArrayList<Vacuna> obtenerVacunas() {
        ArrayList<Vacuna> vacunas = new ArrayList<>();
        // readable porque no vamos a modificar, solamente leer
        SQLiteDatabase baseDeDatos = ayudanteBaseDeDatos.getReadableDatabase();

        String[] columnasAConsultar = {"nombre", "laboratorio", "pais", "fechaAutorizacion"};
        Cursor cursor = baseDeDatos.query(
                NOMBRE_TABLA,//from vacunas
                columnasAConsultar,
                null,
                null,
                null,
                null,
                null
        );

        if (cursor == null) {
            /*
                Salimos aquí porque hubo un error, regresar
                lista vacía
             */
            return vacunas;

        }
        // Si no hay datos, igualmente regresamos la lista vacía
        if (!cursor.moveToFirst()) return vacunas;

        // En caso de que sí haya, iteramos y vamos agregando los
        // datos a la lista de vacunas
        do {
            // El 0 es el número de la columna, como seleccionamos
            // nombre, edad,id entonces el nombre es 0, edad 1 e id es 2
            String nombreObtenidoDeBD = cursor.getString(0);
            String laboratorioObtenidoDeBD = cursor.getString(1);
            String paisObtenidoDeBD = cursor.getString(2);
            String fechaAutorizacionObtenidaDeBd = cursor.getString(3);
            long idVacuna = cursor.getLong(4);

            Vacuna vacunaObtenidaDeBD = new Vacuna(nombreObtenidoDeBD, laboratorioObtenidoDeBD, paisObtenidoDeBD, fechaAutorizacionObtenidaDeBd, idVacuna);
            vacunas.add(vacunaObtenidaDeBD);
        } while (cursor.moveToNext());

        // Fin del ciclo. Cerramos cursor y regresamos la lista de vacunas :)
        cursor.close();
        return vacunas;
    }
}