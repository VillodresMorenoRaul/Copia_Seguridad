package me.parzibyte.crudsqlite.modelos;

public class Vacuna {

    private String nombre;
    private String laboratorio;
    private String pais;
    private String fechaAutorizacion;

    private long id; // El ID de la BD

    public Vacuna(String nombre, String laboratorio, String pais, String fechaAutorizacion) {
        this.nombre = nombre;
        this.laboratorio = laboratorio;
        this.pais = pais;
        this.fechaAutorizacion = fechaAutorizacion;
    }

    // Constructor para cuando instanciamos desde la BD


    public Vacuna(String nombre, String laboratorio, String pais, String fechaAutorizacion, long id) {
        this.nombre = nombre;
        this.laboratorio = laboratorio;
        this.pais = pais;
        this.fechaAutorizacion = fechaAutorizacion;
        this.id = id;
    }


    //Getters

    public String getNombre() {
        return nombre;
    }

    public String getLaboratorio() {
        return laboratorio;
    }

    public String getPais() {
        return pais;
    }

    public String getFechaAutorizacion() {
        return fechaAutorizacion;
    }

    public long getId() {
        return id;
    }

    //Setters

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setLaboratorio(String laboratorio) {
        this.laboratorio = laboratorio;
    }

    public void setPais(String pais) {
        this.pais = pais;
    }

    public void setFechaAutorizacion(String fechaAutorizacion) {
        this.fechaAutorizacion = fechaAutorizacion;
    }

    public void setId(long id) {
        this.id = id;
    }

    //ToString
    @Override
    public String toString() {
        return "Vacuna{" +
                "nombre='" + nombre + '\'' +
                ", laboratorio='" + laboratorio + '\'' +
                ", pais='" + pais + '\'' +
                ", fechaAutorizacion='" + fechaAutorizacion + '\'' +
                ", id=" + id +
                '}';
    }
}
